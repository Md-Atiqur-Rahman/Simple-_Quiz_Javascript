var currentQuestion = 0;
var score = 0;
var totalQuestion = questions.length;

var container = document.getElementById('quizContainer');
var questionEl = document.getElementById('question');
var op1 = document.getElementById('opt1');
var op2 = document.getElementById('opt2');
var op3 = document.getElementById('opt3');
var op4 = document.getElementById('opt4');
var nextButton = document.getElementById('nextButton');
var resultCont = document.getElementById('result');

function loadQuestion(questionIndex) {
    var q = questions[questionIndex];
    questionEl.textContent = (questionIndex + 1) + '. ' + q.question;
    op1.textContent = q.option1;
    op2.textContent = q.option2;
    op3.textContent = q.option3;
    op4.textContent = q.option4;
};

window.addEventListener("load", function () {
    document.getElementById('previousButton').hidden = "hidden";
    
   
}, false);
function loadPreviousQuestion() {
    currentQuestion--;
    loadQuestion(currentQuestion);
    
};


function loadNextQuestion() {
    var selectedOption = document.querySelector('input[type=radio]:checked');
    if (!selectedOption) {
        alert('Please select your answer');
        return;
    }
        var answer = selectedOption.value;
        if (questions[currentQuestion].answer == answer) {
            score += 2;
        }
        selectedOption.checked = false;
        currentQuestion++;
        if(currentQuestion==totalQuestion-1)
        {
            nextButton.textContent = 'Finish';
            nextButton.style.backgroundColor = "Red";
        }
        if (currentQuestion == totalQuestion) {
            container.style.display = 'none';
            resultCont.style.display = '';
            resultCont.textContent = 'Your Score is : ' + score;
           
            return;
        }
        loadQuestion(currentQuestion);
    
        document.getElementById('previousButton').hidden = false;
}
loadQuestion(currentQuestion);
